#pragma once
#include "quantum.h"
#include "process_records.h"

#ifdef TAP_DANCE_ENABLE
    #include "tap_dance.h"
#endif
