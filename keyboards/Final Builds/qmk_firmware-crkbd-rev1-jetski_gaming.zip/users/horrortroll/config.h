/* Copyright 2023 HorrorTroll <https://github.com/HorrorTroll>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

/* Forcing to use NKRO instead 6KRO */
#define FORCE_NKRO

#define DYNAMIC_KEYMAP_LAYER_COUNT 2

#if defined(__arm__)
    #ifdef RGB_MATRIX_ENABLE
        #define RGB_MATRIX_SOLID_REACTIVE_GRADIENT_MODE
    #endif
#endif

#if defined(__AVR_ATmega32U4__)
    #define NO_ACTION_ONESHOT

    #ifdef RGB_MATRIX_ENABLE
        /* RGB Matrix effect */
        #undef ENABLE_RGB_MATRIX_GRADIENT_UP_DOWN
        #undef ENABLE_RGB_MATRIX_GRADIENT_LEFT_RIGHT
        #undef ENABLE_RGB_MATRIX_BAND_SAT
        #undef ENABLE_RGB_MATRIX_BAND_VAL
        #undef ENABLE_RGB_MATRIX_BAND_PINWHEEL_SAT
        #undef ENABLE_RGB_MATRIX_BAND_PINWHEEL_VAL
        #undef ENABLE_RGB_MATRIX_BAND_SPIRAL_SAT
        #undef ENABLE_RGB_MATRIX_BAND_SPIRAL_VAL
        #undef ENABLE_RGB_MATRIX_CYCLE_UP_DOWN
        #undef ENABLE_RGB_MATRIX_RAINBOW_MOVING_CHEVRON
        #undef ENABLE_RGB_MATRIX_CYCLE_OUT_IN_DUAL
        #undef ENABLE_RGB_MATRIX_DUAL_BEACON
        #undef ENABLE_RGB_MATRIX_RAINBOW_BEACON
        #undef ENABLE_RGB_MATRIX_RAINBOW_PINWHEELS
        #undef ENABLE_RGB_MATRIX_RAINDROPS
        #undef ENABLE_RGB_MATRIX_JELLYBEAN_RAINDROPS
        #undef ENABLE_RGB_MATRIX_HUE_WAVE
        #undef ENABLE_RGB_MATRIX_PIXEL_RAIN

        #undef ENABLE_RGB_MATRIX_SOLID_REACTIVE
        #undef ENABLE_RGB_MATRIX_SOLID_REACTIVE_WIDE
        #undef ENABLE_RGB_MATRIX_SOLID_REACTIVE_MULTIWIDE
        #undef ENABLE_RGB_MATRIX_SOLID_REACTIVE_CROSS
        #undef ENABLE_RGB_MATRIX_SOLID_REACTIVE_MULTICROSS
        #undef ENABLE_RGB_MATRIX_SOLID_REACTIVE_NEXUS
        #undef ENABLE_RGB_MATRIX_SPLASH
        #undef ENABLE_RGB_MATRIX_SOLID_SPLASH
        #undef ENABLE_RGB_MATRIX_SOLID_MULTISPLASH
    #endif
#endif
